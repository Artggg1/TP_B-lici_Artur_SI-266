# Laborator: funcții, metode și importuri pe web
# Student: Bîlici Artur SI-266
import requests
import urllib.request
import time
from requests import get
import requests as rq
from webtools import pause
BASE_URL = 'https://cybercor.org'
ECHO_URL = 'https://httpbin.org'
TIMEOUT = 10
# 1. requests este externă; urllib este inclusă în biblioteca standard.
# Modul: fișier Python; pachet: grup de module; bibliotecă: colecție de instrumente.

def main():
    """Demonstrează cele opt exerciții despre importuri."""
    print('1. Versiune:', requests.__version__)
    # 2. requests.get arată proveniența; get este mai scurt.
    # 3. rq scurtează numele; aliasurile neobișnuite pot reduce claritatea.
    for number, function in [(2, requests.get), (2, get), (3, rq.get)]:
        try:
            pause()
            print(number, function(BASE_URL, timeout=TIMEOUT).status_code)
        except requests.RequestException as error:
            print(number, 'Conexiune indisponibilă:', error)
    try:
        pause()
        with urllib.request.urlopen(BASE_URL, timeout=TIMEOUT) as response:
            print('4.', response.status, response.read().decode('utf-8')[:200])
    except (OSError, UnicodeError) as error:
        print('4. Eroare:', error)
    print('5.', dir(requests))
    # get: funcție; Session: clasă; exceptions: modul.
    print('6. Documentație:')
    help(requests.get)  # timeout se transmite prin **kwargs.
    try:
        pause()
        response = requests.get(BASE_URL, timeout=TIMEOUT)
        print('6.', response.status_code)
        pause()
        start = time.perf_counter()
        response = requests.get(BASE_URL, timeout=TIMEOUT)
        print('7. Total:', time.perf_counter() - start,
              'până la antete:', response.elapsed.total_seconds())
        # elapsed nu include descărcarea întregului corp; perf_counter o include.
    except requests.RequestException as error:
        print('6–7. Eroare:', error)
    try:
        import bs4
        print('8. bs4 este instalat.')
    except ImportError:
        print('Instalați modulul cu: pip install beautifulsoup4.')

if __name__ == '__main__':
    main()
