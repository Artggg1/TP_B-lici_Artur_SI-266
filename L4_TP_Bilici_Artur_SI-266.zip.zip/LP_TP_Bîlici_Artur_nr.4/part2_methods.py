# Laborator: funcții, metode și importuri pe web
# Student: Bîlici Artur SI-266
import requests
from webtools import fetch, pause, get_title
BASE_URL = 'https://cybercor.org'
ECHO_URL = 'https://httpbin.org'
TIMEOUT = 10

def main():
    """Demonstrează exercițiile 9–20 despre metode și atribute."""
    try:
        response = fetch(BASE_URL)
        print('9.', response.status_code)  # atribut
        print(response.ok)  # atribut
        print(response.url)  # atribut
        print(response.encoding)  # atribut
        try:
            response.raise_for_status()  # metodă
        except requests.HTTPError as error:
            print('10. Pagina principală a returnat o eroare:', error)
        try:
            fetch(BASE_URL + '/this-page-does-not-exist').raise_for_status()
        except requests.HTTPError:
            print('10. Pagina solicitată nu poate fi accesată.')
        except requests.RequestException as error:
            print('10. Eroare de conexiune:', error)
        for name, value in response.headers.items():
            print(f'11. {name}: {value}')
        print('12.', response.headers.get('Server', 'lipsește'))
        print(response.headers.get('Content-Type', 'lipsește'))
        print(response.headers.get('content-type', 'lipsește'))
        # Antetele HTTP nu țin cont de majuscule/minuscule.
        print('13.', response.text.lower().count('cyber'))
        # lower returnează un str, pe care putem apela metoda count.
        print('14.', get_title(response.text))
        lines = response.text.splitlines()
        print('15.', len(lines), len(max(lines, key=len, default='')))
        print('16.', 'Conexiune securizată' if response.url.startswith('https://')
              else 'Conexiune nesecurizată')
        redirected = fetch('http://cybercor.org')
        for previous in redirected.history:
            print('17.', previous.status_code, previous.url)
        print('Final:', redirected.url)
        pause()
        head = requests.head(BASE_URL, timeout=TIMEOUT)
        get_response = fetch(BASE_URL)
        print('18. HEAD:', len(head.content), 'GET:', len(get_response.content))
        # HEAD nu returnează corpul paginii; GET îl descarcă.
        if not response.cookies:
            print('19. Niciun cookie setat.')
        for cookie in response.cookies:
            print('19.', cookie.name, cookie.secure)
    except requests.RequestException as error:
        print('Site indisponibil:', error)
    try:
        with requests.Session() as session:
            session.headers.update({'User-Agent': 'WebLab-Bilici_Artur'})
            pause()
            response = session.get(ECHO_URL + '/headers', timeout=TIMEOUT)
            response.raise_for_status()
            agent = response.json().get('headers', {}).get('User-Agent')
            print('20.', agent, 'Confirmat:', agent == 'WebLab-Nume_Prenume')
    except (requests.RequestException, ValueError) as error:
        print('20. Verificare indisponibilă:', error)
    # text este atribut; json() este metodă care decodează corpul în obiecte Python.

if __name__ == '__main__':
    main()
