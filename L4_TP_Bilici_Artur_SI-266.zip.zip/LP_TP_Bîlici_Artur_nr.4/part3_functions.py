# Laborator: funcții, metode și importuri pe web
# Student: Bîlici Artur SI-266
import requests
from webtools import (fetch, get_status, get_title, page_exists, check_paths,
                      get_header, security_headers, score_headers, fetch_robots,
                      disallowed_paths, response_times, log)
BASE_URL = 'https://cybercor.org'
ECHO_URL = 'https://httpbin.org'
TIMEOUT = 10
# Funcțiile 21–34 sunt definite în webtools.py și refolosite aici (cerința 44).
# Adnotările documentează tipurile, dar Python nu le verifică automat.
# print afișează; return transmite valoarea apelantului.

def main():
    """Apelează cel puțin o dată fiecare funcție din exercițiile 21–34."""
    actions = [
        (21, lambda: fetch(BASE_URL).status_code),
        (22, lambda: [(p, get_status(BASE_URL + p)) for p in ['/', '/robots.txt', '/sitemap.xml']]),
        (23, lambda: (fetch(BASE_URL).status_code, fetch(BASE_URL, timeout=3).status_code)),
        (24, lambda: get_title(fetch(BASE_URL).text)),
        (25, lambda: help(get_title)),
        (26, lambda: get_status(123)),
        (27, lambda: (page_exists(BASE_URL), page_exists('https://this-domain-does-not-exist.invalid'))),
        (28, lambda: check_paths(BASE_URL, ['/', '/robots.txt', '/sitemap.xml'])),
        (29, lambda: get_header(BASE_URL, name='Server')),
        (30, lambda: security_headers(BASE_URL)),
        (31, lambda: score_headers(security_headers(BASE_URL))),
        (32, lambda: (disallowed_paths(fetch_robots(BASE_URL)), disallowed_paths(None))),
        (33, lambda: response_times(BASE_URL, BASE_URL + '/robots.txt')),
        (34, lambda: log('verificat', url=BASE_URL, status=200)),
    ]
    for number, action in actions:
        try:
            print(f'{number}.', action())
        except (requests.RequestException, AttributeError, TypeError, ValueError) as error:
            print(f'{number}. Eroare tratată:', error)
    # La 26 requests respinge URL-ul 123; nu adnotarea de tip produce eroarea.

if __name__ == '__main__':
    main()
