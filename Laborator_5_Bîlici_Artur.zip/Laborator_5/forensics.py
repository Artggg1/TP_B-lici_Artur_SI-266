import re
import zipfile
from pathlib import Path
from PIL import Image, ExifTags

ROOT = Path(__file__).resolve().parent

def tip_real(cale):
    with open(cale, 'rb') as f:
        cap = f.read(8)
    if cap.startswith(b'%PDF'): return 'pdf'
    if cap.startswith(b'\x89PNG'): return 'png'
    if cap.startswith(b'\xff\xd8'): return 'jpeg'
    if cap.startswith(b'PK\x03\x04'): return 'zip/docx'
    return 'necunoscut (' + cap.hex() + ')'

def extrage_text(cale):
    date = Path(cale).read_bytes()
    return [x.decode('ascii') for x in re.findall(rb'[ -~]{4,}', date)]

def grad_zecimal(valori, emisfera):
    d, m, s = [float(x) for x in valori]
    numar = d + m / 60 + s / 3600
    return -numar if emisfera in ('S', 'W') else numar

def citeste_exif(cale):
    exif = Image.open(cale).getexif()
    print('EXIF:')
    for tag, val in exif.items():
        print(' ', ExifTags.TAGS.get(tag, tag), ':', val)
    gps = exif.get_ifd(34853)
    if not gps:
        print('GPS: absent')
        return None
    gps = {ExifTags.GPSTAGS.get(k, k): v for k, v in gps.items()}
    lat = grad_zecimal(gps['GPSLatitude'], gps['GPSLatitudeRef'])
    lon = grad_zecimal(gps['GPSLongitude'], gps['GPSLongitudeRef'])
    print('GPS:', lat, lon)
    return lat, lon

def extrage_zip(cale):
    date = Path(cale).read_bytes()
    i = date.find(b'PK\x03\x04')
    if i == -1:
        print('ZIP nu a fost gasit')
        return []
    iesire = ROOT / 'gasit.zip'
    iesire.write_bytes(date[i:])
    print('Arhiva extrasa de la octetul:', i)
    with zipfile.ZipFile(iesire) as z:
        nume = z.namelist()
        print('Continut ZIP:', nume)
        # Afisam continutul fara a extrage cai dintr-o arhiva necunoscuta.
        for n in nume:
            if not n.endswith('/'):
                print(n, ':', z.read(n).decode('utf-8', errors='replace')[:500])
        return nume

if __name__ == '__main__':
    for nume in ('foto.jpg', 'ascuns.png'):
        print(nume, 'tip real:', tip_real(ROOT / 'probe' / nume))
    print('Siruri citibile din ascuns.png (primele 20):')
    print(extrage_text(ROOT / 'probe/ascuns.png')[:20])
    citeste_exif(ROOT / 'probe/foto.jpg')
    extrage_zip(ROOT / 'probe/ascuns.png')
