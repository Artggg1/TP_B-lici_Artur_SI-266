# Laborator: funcții, metode și importuri pe web
# Student: Bîlici Artur SI-266
import argparse
import csv
from datetime import datetime
from pathlib import Path
import requests
import webtools
from webtools import get_title, security_headers, DEFAULT_HEADERS

BASE_URL = 'https://cybercor.org'
ECHO_URL = 'https://httpbin.org'
TIMEOUT = 10
# 44: import webtools păstrează numele modulului în apeluri.
# 45: o definiție proprie get_title după import ar înlocui numele importat.
# 46: autotestul din webtools nu rulează la import.

def main():
    """Execută exercițiile 44–50 și scrie rapoartele CSV și JSON."""
    parser = argparse.ArgumentParser(description='Raport web pentru laboratorul 4')
    parser.add_argument('url', nargs='?', default=BASE_URL)
    args = parser.parse_args()
    print('DEFAULT_HEADERS:', DEFAULT_HEADERS)
    try:
        print('44. Titlu:', webtools.get_title(webtools.fetch(args.url).text))
        print('45. Antete:', security_headers(args.url))
    except requests.RequestException as error:
        print('Pagina nu poate fi citită:', error)
    paths = webtools.check_paths(args.url, ['/', '/robots.txt', '/sitemap.xml'])
    with Path(__file__).with_name('report.csv').open('w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['path', 'status', 'checked_at'])
        for path, status in paths.items():
            writer.writerow([path, status if status is not None else 'indisponibil',
                             datetime.now().isoformat()])
    webtools.site_report(args.url)

if __name__ == '__main__':
    main()
