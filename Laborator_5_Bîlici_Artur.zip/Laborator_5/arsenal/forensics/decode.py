import argparse
import base64
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]

def ghici_strat(s):
    s = s.strip()
    if re.search(r'%[0-9a-fA-F]{2}', s):
        return 'url'
    if s and len(s) % 2 == 0 and re.fullmatch(r'[0-9a-fA-F]+', s):
        return 'hex'
    if len(s) >= 4 and len(s) % 4 == 0 and re.fullmatch(r'[A-Za-z0-9+/]+={0,2}', s):
        return 'base64'
    return 'necunoscut'

def desfa(s):
    strat = ghici_strat(s)
    try:
        if strat == 'url':
            return strat, unquote(s).encode('utf-8')
        if strat == 'hex':
            return strat, bytes.fromhex(s)
        if strat == 'base64':
            return strat, base64.b64decode(s, validate=True)
    except (ValueError, UnicodeError):
        pass
    return 'necunoscut', s.encode('utf-8')

def citibil(b):
    return all(32 <= c < 127 for c in b)

def straturi(text, maxim=8):
    pasi = []
    for _ in range(maxim):
        tip, rezultat = desfa(text)
        if tip == 'necunoscut':
            break
        pasi.append(tip)
        try:
            text_nou = rezultat.decode('utf-8')
        except UnicodeDecodeError:
            return pasi, rezultat
        if text_nou == text:
            break
        text = text_nou
        # Nu ne oprim numai pentru ca e ASCII: Base64 si hex sunt si ele citibile.
        if ghici_strat(text) == 'necunoscut':
            break
    return pasi, text.encode('utf-8')

def sparge_xor(date):
    rezultate = []
    for k in range(256):
        clar = bytes(b ^ k for b in date)
        if citibil(clar):
            rezultate.append((k, clar.decode('ascii')))
    # Mai intai variantele cu spatii (mai probabil propozitii).
    return sorted(rezultate, key=lambda x: (-x[1].count(' '), x[0]))

def sparge_hash(tinta, wordlist):
    tinta = tinta.strip().lower()
    algoritmi = {32: 'md5', 40: 'sha1', 64: 'sha256'}
    algoritm = algoritmi.get(len(tinta))
    if not algoritm or not re.fullmatch('[0-9a-f]+', tinta):
        return None, None
    with open(wordlist, encoding='latin1') as f:
        for linie in f:
            cuvant = linie.strip()
            if hashlib.new(algoritm, cuvant.encode('utf-8')).hexdigest() == tinta:
                return algoritm, cuvant
    return algoritm, None

def main():
    parser = argparse.ArgumentParser(description='Decoder simplu pentru probe locale')
    parser.add_argument('intrare', nargs='?', default='probe/mesaj.txt')
    parser.add_argument('--fisier', action='store_true')
    parser.add_argument('--xor', action='store_true')
    parser.add_argument('--hash', action='store_true')
    a = parser.parse_args()
    cale = ROOT / a.intrare
    if a.xor:
        rezultate = sparge_xor(cale.read_bytes())
        rezultat = {'strat': 'xor', 'candidati': [{'cheie': k, 'text': t} for k, t in rezultate[:10]]}
    elif a.hash:
        algoritm, parola = sparge_hash(cale.read_text().splitlines()[0], ROOT / 'probe/wordlist.txt')
        rezultat = {'strat': algoritm, 'parola': parola}
    else:
        text = cale.read_text(encoding='utf-8').strip() if a.fisier else a.intrare
        pasi, date = straturi(text)
        rezultat = {'strat': pasi, 'rezultat': date.decode('utf-8', errors='replace')}
    iesire = Path(__file__).with_name('fisa.json')
    iesire.write_text(json.dumps(rezultat, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(rezultat, ensure_ascii=False, indent=2))
    print('Fisa salvata:', iesire)

if __name__ == '__main__':
    main()
