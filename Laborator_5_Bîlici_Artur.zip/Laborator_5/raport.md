# Laboratorul 5. Informații invizibile: forensics și steganografie

**Disciplina:** Tehnici de programare  
**Tema:** Forensics și steganografie  
**Notă:** Rezultatele următoare provin din probele **demonstrative**, generate prin `probe/pregateste.py` creat pentru această soluție, NU din probele oficiale ale profesorului.

## Scopul lucrării

Am învățat cum să recunosc și să decodez texte codificate, cum să testez o cheie XOR de un octet și cum să compar hashuri cu o listă de parole. Am analizat și fișiere, metadate și mesaje ascunse într-o imagine.

## Lucrarea A

**A1.** Am transformat textul `Salut` în octeți prin `encode()`, am aflat valoarea hexazecimală cu `hex()` și am refăcut octeții cu `bytes.fromhex()`.

**A2.** Am creat funcția `ghici_strat()` pentru a identifica URL, Hex și Base64 după caractere.

**A3.** Am creat funcția `desfa()` care întoarce tipul și octeții decodați.

**A4.** Am repetat decodarea în buclă pentru a elimina straturile succesive. Pentru `probe/mesaj.txt` am obținut: **base64 → hex → base64**, apoi mesajul `Mesaj demonstrativ pentru laboratorul 5`.

**A5.** Am testat cele 256 de chei posibile pentru fișierul XOR. Am găsit **cheia 42**, iar mesajul a fost: `Acesta este un mesaj XOR de laborator.`

**A6.** Am recunoscut un hash **SHA-256** după lungimea de 64 de caractere hexazecimale. Comparând hashurile generate din lista de cuvinte, am găsit **parola demonstrativă `parola_lab`**.

**A7.** Am folosit `argparse`, am salvat rezultatul în `arsenal/forensics/fisa.json` și am verificat decoderul prin teste automate.

## Lucrarea B

**B1.** Am citit primele caractere binare (magic bytes): `probe/foto.jpg` este **JPEG**, iar `probe/ascuns.png` este **PNG**.

**B2.** Am extras secvențe de text imprimabil din `ascuns.png`. Printre ele apare `indiciu.txt`.

**B3.** Din fotografia demonstrativă am citit metadatele EXIF și coordonatele GPS **47.025, 28.833333**. Coordonatele sunt inventate pentru exercițiu, nu sunt o locație constatată dintr-o fotografie reală.

**B4.** Am găsit semnătura ZIP la octetul **724**, am salvat arhiva în `gasit.zip`, iar în ea am găsit fișierul `indiciu.txt` cu textul `Acesta este fisierul demonstrativ ascuns in PNG.`.

**B5.** Am ascuns mesajul `FLAG{ascuns_in_pixeli}` în biții cei mai puțin semnificativi (LSB) ai pixelilor și am salvat imaginea în format PNG.

**B6.** Am citit biții din `stego.png`, i-am transformat în octeți și am recuperat mesajul exact: **`FLAG{ascuns_in_pixeli}`**.

## Verificare

Am rulat `python -m pytest teste -q`: **4 teste au trecut**. Au fost executate și scripturile `forensics.py` și `stego.py`.

## Concluzie

În urma acestei lucrări am înțeles mai bine diferența dintre text și octeți și am văzut cum sunt folosite codările Base64, Hex și URL. Am învățat să încerc toate cheile posibile pentru un XOR simplu și să verific un hash folosind o listă de cuvinte. De asemenea, am analizat fișierele după semnătură, am citit metadatele unei fotografii și am găsit o arhivă ZIP ascunsă într-un PNG. La final am ascuns un mesaj într-o imagine și l-am recuperat. Cel mai important lucru învățat este că fișierele pot conține informații care nu se văd direct atunci când le deschidem.

## Bibliografie

- Fișa de laborator 5, „Informații invizibile: forensics și steganografie”, UTM, FCIM.
- Documentația oficială Python: https://docs.python.org/3/
- Documentația Pillow: https://pillow.readthedocs.io/
