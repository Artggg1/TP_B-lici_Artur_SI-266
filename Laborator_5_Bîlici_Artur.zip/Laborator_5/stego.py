from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent

def ascunde(sursa, destinatie, mesaj):
    img = Image.open(sursa).convert('RGB')
    pixeli = list(img.getdata())
    date = mesaj.encode('utf-8') + b'\x00'
    biti = ''.join(f'{x:08b}' for x in date)
    canale = [c for pixel in pixeli for c in pixel]
    if len(biti) > len(canale):
        raise ValueError('Imagine prea mica pentru mesaj')
    for i, bit in enumerate(biti):
        canale[i] = (canale[i] & ~1) | int(bit)
    noi = [tuple(canale[i:i+3]) for i in range(0, len(canale), 3)]
    img.putdata(noi)
    img.save(destinatie)

def dezvaluie(cale):
    img = Image.open(cale).convert('RGB')
    biti = ''.join(str(c & 1) for pixel in img.getdata() for c in pixel)
    mesaj = bytearray()
    for i in range(0, len(biti) - 7, 8):
        octet = int(biti[i:i+8], 2)
        if octet == 0:
            break
        mesaj.append(octet)
    return mesaj.decode('utf-8')

if __name__ == '__main__':
    text = 'FLAG{ascuns_in_pixeli}'
    ascunde(ROOT / 'probe/foto.jpg', ROOT / 'stego.png', text)
    print('Mesajul dezvaluit:', dezvaluie(ROOT / 'stego.png'))
