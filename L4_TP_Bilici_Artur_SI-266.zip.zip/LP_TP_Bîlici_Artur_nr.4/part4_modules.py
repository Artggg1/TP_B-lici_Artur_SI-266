# Laborator: funcții, metode și importuri pe web
# Student: Bîlici Artur SI-266
import json
from pathlib import Path
from urllib.parse import urlparse, urljoin
import requests
from webtools import fetch, extract_links, split_links, ImageFinder, page_fingerprint, resolve, cert_days_left
BASE_URL = 'https://cybercor.org'
ECHO_URL = 'https://httpbin.org'
TIMEOUT = 10

def parse_url():
    """35. Afișează cele cinci componente ale URL-ului."""
    parts = urlparse('https://cybercor.org/path?x=1#top')
    print(parts.scheme, parts.netloc, parts.path, parts.query, parts.fragment)

def join_urls():
    """36. Transformă cele trei căi relative în URL-uri absolute."""
    for link in ['/about', 'contact.html', '../index.html']:
        print(urljoin(BASE_URL, link))

def test_images():
    """39. Testează parserul pe HTML cu rezultat cunoscut."""
    html = '''<html><body><img src="/logo.png" alt="Logo">
    <IMG SRC="poza.jpg"><img alt="imagine fără src">
    <img src="https://cdn.example.com/banner.webp" />
    <a href="/despre">Aceasta nu este o imagine</a></body></html>'''
    finder = ImageFinder()
    finder.feed(html)
    print(finder.images)
    assert finder.images == ['/logo.png', 'poza.jpg', 'https://cdn.example.com/banner.webp']
    print('Testul a trecut!')
    # HTMLParser.feed apelează automat handle_starttag.

def find_images(html):
    """39. Extrage imaginile paginii reale și compară numărul de taguri."""
    finder = ImageFinder()
    finder.feed(html)
    print(len(finder.images), 'imagini găsite; <img în text:', html.lower().count('<img'))
    for src in finder.images:
        print(src)
    # Comparația suplimentară în browser se face manual cu Ctrl+U.

def save_headers(response):
    """41. Salvează antetele în JSON și le încarcă înapoi."""
    path = Path(__file__).with_name('headers.json')
    with path.open('w', encoding='utf-8') as file:
        json.dump(dict(response.headers), file, indent=2)
    with path.open(encoding='utf-8') as file:
        headers = json.load(file)
    print(headers.get('Content-Type', 'lipsește'))

def main():
    """Execută exercițiile 35–43; tratează lipsa conexiunii."""
    parse_url()
    join_urls()
    test_images()
    try:
        response = fetch(BASE_URL)
        links = extract_links(response.text)  # 37
        print('37.', links)
        print('38.', split_links(links, BASE_URL))
        find_images(response.text)
        first = page_fingerprint(BASE_URL)
        second = page_fingerprint(BASE_URL)
        print('40.', first, second, 'Identice:', first == second)
        # Diferă dacă se schimbă corpul: conținut dinamic sau pagina actualizată.
        save_headers(response)
    except requests.RequestException as error:
        print('Conexiune indisponibilă:', error)
    for number, function in [(42, resolve), (43, cert_days_left)]:
        try:
            print(number, function('cybercor.org'))
        except OSError as error:
            print(number, 'Conexiune indisponibilă:', error)

if __name__ == '__main__':
    main()
