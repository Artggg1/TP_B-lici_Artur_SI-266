# Laborator: funcții, metode și importuri pe web
# Student: Bîlici Artur SI-266
BASE_URL = 'https://cybercor.org'
ECHO_URL = 'https://httpbin.org'
TIMEOUT = 10

def get_title(html):
    """Extrage titlul cu BeautifulSoup, inclusiv titluri cu atribute."""
    from bs4 import BeautifulSoup
    title = BeautifulSoup(html, 'html.parser').find('title')
    return title.get_text().strip() if title else ''

def extract_links(html):
    """Extrage href inclusiv din atribute scrise cu apostrofuri."""
    from bs4 import BeautifulSoup
    return list(dict.fromkeys(a['href'] for a in
                             BeautifulSoup(html, 'html.parser').find_all(href=True)))

def main():
    """Demonstrează bonusul fără cereri suplimentare de rețea."""
    try:
        html = "<title lang='ro'> Test </title><a href='/about'>Despre</a>"
        print(get_title(html), extract_links(html))
        # Parserul gestionează atributele și apostrofurile; find/regex sunt mai limitate.
    except ImportError:
        print('Instalați modulul cu: pip install beautifulsoup4.')

if __name__ == '__main__':
    main()
