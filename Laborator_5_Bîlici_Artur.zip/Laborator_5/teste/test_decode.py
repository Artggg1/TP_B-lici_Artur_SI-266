from arsenal.forensics.decode import desfa, ghici_strat, straturi, sparge_xor
from stego import ascunde, dezvaluie

def test_base64():
    strat, b = desfa('U2FsdXQ=')
    assert strat == 'base64'
    assert b == b'Salut'

def test_hex_url():
    assert desfa('48656c6c6f')[1] == b'Hello'
    assert desfa('%2Fetc')[1] == b'/etc'

def test_straturi():
    assert straturi('U2FsdXQ=')[1] == b'Salut'

def test_xor():
    criptat = bytes(c ^ 42 for c in b'Acesta este text de test.')
    assert (42, 'Acesta este text de test.') in sparge_xor(criptat)
