Laboratorul 4 — Funcții, metode și importuri pe web

1. Dezarhivează proiectul și deschide directorul web_lab în PyCharm.
2. Selectează un interpretor Python 3.9 sau mai nou.
3. În terminalul PyCharm, din web_lab, execută:
   python -m pip install -r requirements.txt
4. Rulează fiecare parte:
   python part1_imports.py
   python part2_methods.py
   python part3_functions.py
   python part4_modules.py
5. Proiectul final (exercițiile 44–50):
   python main.py https://cybercor.org
6. Autotest modul: python webtools.py
   Bonus: python bonus_bs4.py

Funcțiile părților 3 și 4 se află în webtools.py și sunt importate în
fișierele respective. Fiecare exercițiu este marcat prin număr.
report.csv și report.json se creează lângă main.py. headers.json se creează
la rularea părții 4. Nu modifica fișierele cu rapoarte manual.

Completează numele, prenumele și grupa înainte de predare. Înlocuiește
Nume_Prenume în User-Agent. Redenumește arhiva:
L4_TP_Nume_Prenume_Grupa.zip (de exemplu SI-266 pentru grupă).
Subiectul emailului trebuie să fie numele arhivei fără extensia .zip.

Observație privind cerințele: exercițiul 47 cere folosirea antetului
personalizat, dar regulile îl rezervă pentru httpbin.org. fetch folosește
DEFAULT_HEADERS doar pentru httpbin.org, respectând regula de lucru.

Validare: testele locale verifică logica și generarea rapoartelor cu
răspunsuri simulate. Fișierele report.csv/report.json incluse sunt marcate
ca SIMULATE; nu reprezintă măsurători reale. Rulează main.py cu acces la
internet înainte de predare pentru a le înlocui cu rezultatele reale.
Erorile de rețea sunt afișate și înregistrate, fără rezultate inventate.

Noțiuni de explicat:
- import: aduce codul altui modul;
- atribut: o valoare, de exemplu response.status_code;
- metodă: o acțiune, de exemplu response.json();
- funcție: bloc reutilizabil, definit cu def;
- return: transmite un rezultat; print: îl afișează;
- *urls: mai multe argumente poziționale;
- **details: mai multe argumente cu nume;
- __name__ == '__main__': execută codul numai la rularea directă;
- timeout: limitează așteptarea operațiilor de rețea, nu garantează
  o limită totală strictă pentru întreaga descărcare;
- scorul antetelor verifică numai prezența, nu calitatea configurării.
