# Laboratorul 5 — Forensics și steganografie

Proiect demonstrativ creat după fișa de laborator. `probe/pregateste.py` este **propriu**, nu scriptul oferit de profesor, deci rezultatele pot să difere de probele oficiale.

Necesită Python 3.10+ și `pillow` (`pip install pillow`). Rulează comenzile din `Laborator_5`:

```bash
python probe/pregateste.py
python arsenal/forensics/decode.py probe/mesaj.txt --fisier
python arsenal/forensics/decode.py probe/xor.bin --xor
python arsenal/forensics/decode.py probe/hashuri.txt --hash
python forensics.py
python stego.py
python -m pytest teste -q
```

Pentru testare fără pytest: `python -c "from teste.test_decode import test_base64, test_hex_url, test_straturi, test_xor; test_base64(); test_hex_url(); test_straturi(); test_xor(); print('OK')"`.

**Atenție:** `fisa.json` este suprascrisă de fiecare rulare a decoderului. Rulează ultima dată comanda cu `mesaj.txt` dacă vrei să prezinți decodarea în fișă. Pentru probele oficiale, înlocuiește fișierele demonstrative din `probe` cu cele ale profesorului și actualizează raportul.
