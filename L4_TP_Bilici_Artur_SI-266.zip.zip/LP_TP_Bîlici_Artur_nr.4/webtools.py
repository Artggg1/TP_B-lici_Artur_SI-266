# Laborator: funcții, metode și importuri pe web
# Student: Bîlici Artur SI-266
import time
import re
import json
import socket
import ssl
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse, urljoin
from html.parser import HTMLParser
import requests

BASE_URL = 'https://cybercor.org'
ECHO_URL = 'https://httpbin.org'
TIMEOUT = 10
DEFAULT_HEADERS = {'User-Agent': 'WebLab-Bilici_Artur'}
SECURITY_HEADERS = ['Strict-Transport-Security', 'Content-Security-Policy',
                    'X-Frame-Options', 'X-Content-Type-Options', 'Referrer-Policy']
_last_request = None

def pause():
    """Asigură cel puțin o secundă între cererile succesive."""
    global _last_request
    if _last_request is not None:
        time.sleep(max(0, 1 - (time.perf_counter() - _last_request)))
    _last_request = time.perf_counter()

def fetch(url: str, timeout: float = 10) -> requests.Response:
    """Descarcă un URL prin GET, cu pauză și timeout."""
    pause()
    # Cerința 47 cere DEFAULT_HEADERS; regula generală permite verificarea
    # antetelor personalizate doar pe httpbin, deci le trimitem doar acolo.
    headers = DEFAULT_HEADERS if urlparse(url).hostname == 'httpbin.org' else None
    return requests.get(url, timeout=timeout, headers=headers)

def get_status(url: str) -> int:
    """Returnează codul de stare HTTP."""
    return fetch(url).status_code

def get_title(html: str) -> str:
    """Extrage titlul cu find și slicing; returnează șir gol dacă lipsește."""
    start = html.lower().find('<title>')
    if start == -1:
        return ''
    start += len('<title>')
    end = html.lower().find('</title>', start)
    return html[start:end].strip() if end != -1 else ''

def page_exists(url: str) -> bool:
    """Returnează False la o eroare HTTP sau de conexiune."""
    try:
        response = fetch(url)
        response.raise_for_status()
        return True
    except requests.RequestException:
        return False

def check_paths(base: str, paths: list) -> dict:
    """Verifică fiecare cale; None reprezintă o eroare de conexiune."""
    results = {}
    for path in paths:
        try:
            results[path] = get_status(urljoin(base.rstrip('/') + '/', path))
        except requests.RequestException:
            results[path] = None
    return results

def get_header(url: str, name: str, default: str = 'lipsește') -> str:
    """Returnează un antet sau valoarea implicită."""
    return fetch(url).headers.get(name, default)

def security_headers(url: str) -> dict:
    """Verifică prezența celor cinci antete din cerință."""
    return headers_present(fetch(url))

def headers_present(response: requests.Response) -> dict:
    """Analizează antetele unui răspuns deja descărcat."""
    return {name: name in response.headers for name in SECURITY_HEADERS}

def score_headers(results: dict) -> str:
    """Transformă numărul antetelor prezente într-un scor."""
    return f'{sum(results.values())}/{len(results)}'

def fetch_robots(base: str):
    """Returnează robots.txt sau None dacă nu poate fi citit."""
    try:
        response = fetch(urljoin(base, '/robots.txt'))
        response.raise_for_status()
        return response.text
    except requests.RequestException:
        return None

def disallowed_paths(robots_text) -> list:
    """Extrage valorile Disallow, ignorând comentariile și valorile goale."""
    paths = []
    for line in (robots_text or '').splitlines():
        line = line.split('#', 1)[0].strip()
        key, separator, value = line.partition(':')
        if separator and key.lower() == 'disallow' and value.strip():
            paths.append(value.strip())
    return paths

def response_times(*urls) -> dict:
    """Măsoară durata fiecărei cereri, fără pauza dintre cereri."""
    results = {}
    for url in urls:
        pause()
        start = time.perf_counter()
        try:
            requests.get(url, timeout=TIMEOUT)
            results[url] = time.perf_counter() - start
        except requests.RequestException:
            results[url] = None
    return results

def log(message, **details):
    """Afișează mesajul și argumentele cu nume."""
    print(' | '.join([str(message)] + [f'{k}={v}' for k, v in details.items()]))

def extract_links(html: str) -> list:
    """Extrage href cu expresia regulată cerută, fără duplicate."""
    return list(dict.fromkeys(re.findall(r'href="([^"]+)"', html)))

def split_links(links: list, domain: str) -> tuple:
    """Separă legăturile HTTP/HTTPS interne și externe."""
    base = domain if '://' in domain else 'https://' + domain
    host = urlparse(base).netloc
    internal, external = [], []
    for link in links:
        full = urljoin(base, link)
        parsed = urlparse(full)
        if parsed.scheme not in ('http', 'https'):
            continue  # mailto, tel și javascript nu sunt pagini web.
        target = internal if parsed.netloc == host else external
        if full not in target:
            target.append(full)
    return internal, external

class ImageFinder(HTMLParser):
    """Colectează sursele tagurilor img în ordinea apariției."""
    def __init__(self):
        """Inițializează parserul și lista de imagini."""
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Este apelată automat de feed pentru fiecare tag de început."""
        if tag == 'img':
            src = dict(attrs).get('src')
            if src is not None:
                self.images.append(src)

def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA256 a corpului paginii."""
    import hashlib
    return hashlib.sha256(fetch(url).content).hexdigest()

def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a domeniului."""
    return socket.gethostbyname(hostname)

def cert_days_left(hostname: str) -> int:
    """Verifică certificatul TLS și calculează zilele până la expirare."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure:
            expires = ssl.cert_time_to_seconds(secure.getpeercert()['notAfter'])
    return int((expires - time.time()) // 86400)

def site_report(url: str) -> dict:
    """Colectează, afișează și salvează raportul în report.json."""
    report = {'url': url, 'checked_at': datetime.now(timezone.utc).isoformat(), 'errors': {}}
    try:
        response = fetch(url)
        report.update(status=response.status_code, final_url=response.url,
                      title=get_title(response.text))
        results = headers_present(response)
        internal, external = split_links(extract_links(response.text), response.url)
        report.update(security_headers=results, security_score=score_headers(results),
                      internal_links=len(internal), external_links=len(external))
    except requests.RequestException as error:
        report['errors']['page'] = str(error)
    host = urlparse(url).hostname
    for key, function in [('ip', resolve), ('certificate_days_left', cert_days_left)]:
        try:
            report[key] = function(host)
        except (OSError, ValueError, TypeError) as error:
            report[key] = None
            report['errors'][key] = str(error)
    try:
        parsed = urlparse(url)
        http_url = parsed._replace(scheme='http').geturl()
        response = fetch(http_url)
        report['redirects'] = [{'status': r.status_code, 'url': r.url,
                               'location': r.headers.get('Location')} for r in response.history]
        report['redirect_final_url'] = response.url
    except requests.RequestException as error:
        report['redirects'] = []
        report['errors']['redirects'] = str(error)
    robots = fetch_robots(url)
    report['robots_available'] = robots is not None
    report['disallowed_paths'] = disallowed_paths(robots)
    print(f'=== Raport site: {url} ===')
    labels = {'status': 'Cod de stare', 'final_url': 'URL final', 'title': 'Titlu',
              'ip': 'Adresă IP', 'redirects': 'Redirecționări',
              'security_score': 'Scor securitate', 'certificate_days_left': 'Zile certificat',
              'internal_links': 'Legături interne', 'external_links': 'Legături externe',
              'disallowed_paths': 'Căi interzise'}
    for key, label in labels.items():
        print(f'{label}: {report.get(key, "indisponibil")}')
    for key, error in report['errors'].items():
        print(f'Eroare {key}: {error}')
    Path(__file__).with_name('report.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Salvat în report.json')
    return report

if __name__ == '__main__':
    # Importul setează __name__ la webtools; rularea directă la __main__.
    try:
        print('Autotest:', get_status(BASE_URL))
    except requests.RequestException as error:
        print('Conexiune indisponibilă:', error)
