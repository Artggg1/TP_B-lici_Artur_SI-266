"""Generator DEMONSTRATIV, nu scriptul oficial al profesorului."""
import base64
import hashlib
import io
import zipfile
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent
mesaj = 'Mesaj demonstrativ pentru laboratorul 5'
strat = base64.b64encode(mesaj.encode()).decode()
strat = strat.encode().hex()
strat = base64.b64encode(strat.encode()).decode()
(ROOT / 'mesaj.txt').write_text(strat, encoding='utf-8')
cheie = 42
(ROOT / 'xor.bin').write_bytes(bytes(b ^ cheie for b in b'Acesta este un mesaj XOR de laborator.'))
(ROOT / 'hashuri.txt').write_text(hashlib.sha256(b'parola_lab').hexdigest() + '\n', encoding='utf-8')
(ROOT / 'wordlist.txt').write_text('test\nstudent\nparola_lab\nadmin\n', encoding='latin1')
img = Image.new('RGB', (320, 220), (120, 155, 190))
exif = Image.Exif()
exif[271] = 'Camera laborator demonstrativ'
exif[272] = 'Model Python'
# GPS EXIF: coordonate inventate pentru demonstrarea transformarii in zecimale.
exif[34853] = {1: 'N', 2: (47.0, 1.0, 30.0), 3: 'E', 4: (28.0, 50.0, 0.0)}
try:
    img.save(ROOT / 'foto.jpg', exif=exif)
except Exception:
    exif = Image.Exif()
    exif[271] = 'Camera laborator demonstrativ'
    img.save(ROOT / 'foto.jpg', exif=exif)
img.save(ROOT / 'ascuns.png')
buf = io.BytesIO()
with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('indiciu.txt', 'Acesta este fisierul demonstrativ ascuns in PNG.')
with (ROOT / 'ascuns.png').open('ab') as f:
    f.write(buf.getvalue())
print('Probe demonstrative create in', ROOT)
